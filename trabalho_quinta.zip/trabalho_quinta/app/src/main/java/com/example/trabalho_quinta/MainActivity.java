package com.example.trabalho_quinta;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public class MainActivity extends Activity {

    private static final int REQUEST_SELECT_CONTACTS = 1;

    private ArrayList<Contact> mSelectedContacts;
    private ContactsAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mSelectedContacts = new ArrayList<>();

        mAdapter = new ContactsAdapter(this, mSelectedContacts);
        ListView selectedContactsListView = findViewById(R.id.selectedContactsListView);
        selectedContactsListView.setAdapter(mAdapter);

        Button selectContactsButton = findViewById(R.id.selectContactsButton);
        selectContactsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
                startActivityForResult(intent, REQUEST_SELECT_CONTACTS);
            }
        });

        Button sendSmsButton = findViewById(R.id.sendSmsButton);
        sendSmsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mSelectedContacts.size() > 0) {
                    // Get the first contact in the list
                    Contact contact = mSelectedContacts.get(0);
                    String phoneNumber = contact.getPhoneNumber();

                    // Send an SMS to the contact's phone number
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNumber, null, "Hello, " + contact.getName() + "!", null, null);

                    // Show a toast message to indicate that the SMS was sent
                    Toast.makeText(MainActivity.this, "SMS sent to " + contact.getName(), Toast.LENGTH_SHORT).show();
                } else {
                    // Show a toast message to indicate that no contacts have been selected
                    Toast.makeText(MainActivity.this, "Please select a contact first", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_SELECT_CONTACTS && resultCode == RESULT_OK) {
            Cursor cursor = null;
            try {
                Uri uri = data.getData();
                cursor = getContentResolver().query(uri, null, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    @SuppressLint("Range") String contactId = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
                    @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                    Cursor phones = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + contactId, null, null);
                    while (phones.moveToNext()) {
                        @SuppressLint("Range") String phoneNumber = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                        Contact contact = new Contact(name, phoneNumber);
                        if (!mSelectedContacts.contains(contact)) {
                            mSelectedContacts.add(contact);
                        }
                    }
                    mAdapter.notifyDataSetChanged();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Error selecting contact", Toast.LENGTH_SHORT).show();
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
    }
}
